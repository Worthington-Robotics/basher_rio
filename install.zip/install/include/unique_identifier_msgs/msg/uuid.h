// generated from rosidl_generator_c/resource/idl.h.em
// with input from unique_identifier_msgs:msg/UUID.idl
// generated code does not contain a copyright notice

#ifndef UNIQUE_IDENTIFIER_MSGS__MSG__UUID_H_
#define UNIQUE_IDENTIFIER_MSGS__MSG__UUID_H_

#include "unique_identifier_msgs/msg/detail/uuid__struct.h"
#include "unique_identifier_msgs/msg/detail/uuid__functions.h"
#include "unique_identifier_msgs/msg/detail/uuid__type_support.h"

#endif  // UNIQUE_IDENTIFIER_MSGS__MSG__UUID_H_
